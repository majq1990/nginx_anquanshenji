su - egova <<EOF
 exec "$@"
EOF
