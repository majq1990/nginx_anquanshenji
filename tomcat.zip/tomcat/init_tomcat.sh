#!/bin/bash 

docker_process_init_files() {

    echo
    local f
    for f; do
        case "$f" in
            *.sh)     echo "running $f"; . "$f" ;;
            *)        echo "ignoring $f" ;;
        esac
        echo
    done
}


docker_process_init_files /docker-entrypoint-init.d/*

exec gosu tomcat sh -c  "$@"
